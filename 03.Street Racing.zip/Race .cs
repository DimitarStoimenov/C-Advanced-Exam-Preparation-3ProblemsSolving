﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace StreetRacing
{
    public class Race
    {
        private List<Car> participants;
        private string name;
        private string type;
        private int laps;
        private int capacity;
        private int maxHorsePower;

        public Race(string name, string type, int laps, int capacity, int maxHorsePower)
        {
            
            Name = name;
            Type = type;
            Laps = laps;
            Capacity = capacity;
            MaxHorsePower = maxHorsePower;
            Participants = new List<Car>();
        }

        public List<Car> Participants { get => participants; set => participants = value; }
        public string Name { get => name; set => name = value; }
        public string Type { get => type; set => type = value; }
        public int Laps { get => laps; set => laps = value; }
        public int Capacity { get => capacity; set => capacity = value; }
        public int MaxHorsePower { get => maxHorsePower; set => maxHorsePower = value; }
        public int Count => participants.Count;

        public void Add(Car car)
        {
            if (Participants.Count < capacity)
            {
                if (Participants.Count == 0)
                {
                    if (car.HorsePower <= maxHorsePower)
                    {
                        Participants.Add(car);
                    }
                }
                else
                {
                    foreach (var item in Participants)
                    {
                        if (item.LicensePlate != car.LicensePlate && car.HorsePower <= maxHorsePower)
                        {
                            Participants.Add(car);
                            break;
                        }
                    }
                }
            }
        }
        public bool Remove(string licensePlate)
        {
            foreach (var item in Participants)
            {
                if (item.LicensePlate == licensePlate)
                {
                    Participants.Remove(item);
                    return true;
                }
            }
            return false;
        }
        public Car FindParticipant(string licensePlate)
        {
            Car currCar = Participants.FirstOrDefault(x => x.LicensePlate == licensePlate);

            if (currCar != null)
            {
                return currCar;
            }
            return null;
        }
        public Car GetMostPowerfulCar()
        {
            if (participants.Count == 0)
            {
                return null;
            }
            Car maxcar = null;
            int maxPower = 0;
            foreach (var item in Participants)
            {
                if (item.HorsePower > maxPower)
                {
                    maxPower = item.HorsePower;
                    maxcar = item;
                }
            }
            return maxcar;
        }
       public string  Report()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"Race: {Name} - Type: {Type} (Laps: {Laps})");
            foreach (Car item in Participants)
            {
                sb.AppendLine(item.ToString());
            }
            return sb.ToString().TrimEnd();

        }




    }
}
